THE EVIDENCE ROOM — Holst embed
1. Create a GitHub repository, e.g. wednesday-evidence-room.
2. Upload index.html to the repository root.
3. Open Settings > Pages.
4. Select Deploy from a branch, branch main, folder /(root), then Save.
5. After publishing, copy the HTTPS GitHub Pages URL.
6. Add a website/iframe embed in Holst and use that URL.

Example iframe:
<iframe src="YOUR_GITHUB_PAGES_URL" width="100%" height="850" style="border:none;border-radius:16px;"></iframe>

Answer key: 1-c, 2-d, 3-a, 4-e, 5-f, 6-g, 7-h, 8-b.
